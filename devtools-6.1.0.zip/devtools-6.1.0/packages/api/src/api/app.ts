export type App = any // @TODO
