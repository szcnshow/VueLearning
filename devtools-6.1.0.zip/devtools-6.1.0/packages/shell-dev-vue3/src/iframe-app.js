import { createApp } from 'vue'
import IframeApp from './IframeApp.vue'

createApp(IframeApp).mount('#app')
