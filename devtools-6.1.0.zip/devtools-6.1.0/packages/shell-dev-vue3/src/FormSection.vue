<script>
export default {
  // eslint-disable-next-line vue/name-property-casing
  name: 'form-section',
}
</script>

<template>
  <fieldset>
    <legend>Form section</legend>
    <slot />
  </fieldset>
</template>
