<template>
  <h2>Child route</h2>
</template>

<script>
export default {

}
</script>
