<template>
  <div>
    <p>Hello from before enter route</p>
  </div>
</template>

<script>
export default {
}
</script>
